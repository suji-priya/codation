package com.codation.categoryandproduct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CategoryandproductApplication {

	public static void main(String[] args) {
		SpringApplication.run(CategoryandproductApplication.class, args);
	}

}
