package com.codation.categoryandproduct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CategoryandproductApplicationTests {

	@Test
	void contextLoads() {
	}

}
